"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { ArrowLeft, Check, ChevronRight, Globe, LayoutGrid, List } from "lucide-react";
import { localeOptions, useI18n } from "../i18n";
import { replacePathLocale, type Locale } from "../locales";
import { spotsAuthPath } from "../../../lib/spots-auth-navigation";
import type { AuthUser } from "../../../lib/auth-api";
import type { MenuView } from "./menu-view";

export function VenueMenuSettings({ view, onViewChange, user, onClose }: {
  view: MenuView;
  onViewChange: (view: MenuView) => void;
  user: AuthUser | null;
  onClose: () => void;
}) {
  const { locale, setLocale, t } = useI18n();
  const router = useRouter();
  const pathname = usePathname();
  const [page, setPage] = useState<"menu" | "language" | "view">("menu");
  const dialogRef = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const dialog = dialogRef.current;
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    dialog?.showModal();
    document.body.style.overflow = "hidden";
    const media = window.matchMedia("(max-width: 760px)");
    const resize = () => { if (!media.matches) onClose(); };
    media.addEventListener("change", resize);
    return () => {
      media.removeEventListener("change", resize);
      dialog?.close();
      document.body.style.overflow = overflow;
      previous?.focus();
    };
  }, [onClose]);
  const selectLanguage = (value: Locale) => {
    setLocale(value);
    router.replace(`${replacePathLocale(pathname, value)}${window.location.search}${window.location.hash}`, { scroll: false });
    onClose();
  };
  const openAccount = () => {
    onClose();
    router.push(user ? `/${locale}/discover` : spotsAuthPath(locale, "login", `${pathname}${window.location.search}${window.location.hash}`));
  };
  const language = localeOptions.find((option) => option.value === locale)?.label;
  const viewLabel = t(view === "grid" ? "Карточки" : "Список");
  return <dialog ref={dialogRef} className="spots-mobile-menu-dialog venue-menu-settings" aria-label={t("Настройки меню")} onCancel={(event) => { event.preventDefault(); onClose(); }}>
    <div className="spots-mobile-menu-shell">
      <div className="spots-mobile-menu-heading">
        <button type="button" className="spots-back-button" aria-label={t("Назад")} onClick={() => page === "menu" ? onClose() : setPage("menu")}><ArrowLeft size={26} /></button>
        <h2>{page === "menu" ? <span className="spots-menu-brand"><Image src="/logo.svg" alt="" width={30} height={30} />Pocket Spots</span> : t(page === "language" ? "Язык интерфейса" : "Вид меню")}</h2>
        <span aria-hidden="true" />
      </div>
      {page === "menu" ? <div className="spots-mobile-menu-content">
        <section className="spots-mobile-menu-card spots-mobile-auth-card">
          <h3>{user ? [user.first_name, user.last_name].filter(Boolean).join(" ") || t("Профиль") : t("Войдите в аккаунт")}</h3>
          <p>{t("Сохраняйте места и управляйте бронированиями.")}</p>
          <button type="button" className="spots-mobile-login" onClick={openAccount}>{t(user ? "Открыть Pocket" : "Войти")}</button>
        </section>
        <section className="spots-mobile-menu-card spots-mobile-settings-card" aria-label={t("Меню")}>
          <button type="button" className="spots-mobile-menu-row" aria-label={`${t("Язык интерфейса")}: ${language}`} onClick={() => setPage("language")}>
            <Globe size={21} aria-hidden="true" /><span><strong>{language}</strong></span><ChevronRight size={21} aria-hidden="true" />
          </button>
          <button type="button" className="spots-mobile-menu-row" aria-label={`${t("Вид меню")}: ${viewLabel}`} onClick={() => setPage("view")}>
            {view === "grid" ? <LayoutGrid size={21} aria-hidden="true" /> : <List size={21} aria-hidden="true" />}<span><strong>{t("Вид меню")}</strong><small>{viewLabel}</small></span><ChevronRight size={21} aria-hidden="true" />
          </button>
        </section>
      </div> : <div className="spots-mobile-menu-content spots-mobile-menu-subpage">
        <section className="spots-mobile-menu-card spots-mobile-selection-card" aria-label={t(page === "language" ? "Язык интерфейса" : "Вид меню")}>
          <div className="spots-mobile-selection-options">
            {page === "language" ? localeOptions.map((option) => <button type="button" key={option.value} lang={option.value === "ua" ? "uk" : option.value} aria-pressed={locale === option.value} onClick={() => selectLanguage(option.value)}><span>{option.label}</span>{locale === option.value && <Check size={19} aria-hidden="true" />}</button>) : (["grid", "list"] as const).map((value) => <button type="button" key={value} aria-label={t(value === "grid" ? "Показать сеткой" : "Показать списком")} aria-pressed={view === value} onClick={() => { onViewChange(value); onClose(); }}><span>{t(value === "grid" ? "Карточки" : "Список")}</span>{view === value && <Check size={19} aria-hidden="true" />}</button>)}
          </div>
        </section>
      </div>}
    </div>
  </dialog>;
}
